# ft_irc
./ircserv 6667 5555
nc localhost 6667
USER
NICK
PASS
